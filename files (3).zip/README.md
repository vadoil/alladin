# Niche Analyzer

AI-сервис: ниша → психографический профиль ЦА + порядок блоков сайта.

## Быстрый старт

```bash
# 1. Установить зависимости
npm install

# 2. Ключ Claude API
export ANTHROPIC_API_KEY=sk-ant-...

# 3. Тест из командной строки
node src/test.js "ремонт квартир"

# 4. Или запустить HTTP-сервер
npm start
# → http://localhost:3000
```

## HTTP API

### POST /analyze

```bash
curl -X POST http://localhost:3000/analyze \
  -H "Content-Type: application/json" \
  -d '{"niche": "юридические услуги для ИП"}'
```

Ответ:
```json
{
  "ok": true,
  "cached": true,
  "ms": 1240,
  "data": {
    "niche": "Юридические услуги для малого бизнеса",
    "client_portrait": "...",
    "pains": ["...", "..."],
    "fears": ["...", "..."],
    "trust_triggers": ["...", "..."],
    "tone_of_voice": "...",
    "headline_formula": "...",
    "cta": "...",
    "palette": [
      { "role": "primary", "hex": "#1A2744", "reason": "авторитет" }
    ],
    "block_order": ["hero", "pain_points", "cases", "trust", "faq", "cta_final"]
  }
}
```

## Архитектура

```
rawNiche → normalizeNiche() → findSimilarNiche() → Claude API → JSON
```

- `findSimilarNiche()` — сейчас простой текстовый матч по тегам.
  В production замените на pgvector с векторным поиском по эмбеддингам.
- Кэш — добавьте Redis: ключ = normalized нишa, TTL = 30 дней.
- База ниш — расширяйте `NICHE_DB` в `analyze.js`.
  Минимум нужно 10–15 ниш до запуска.

## Структура

```
src/
  analyze.js   — логика: нормализация + поиск + Claude
  server.js    — Express HTTP API
  test.js      — CLI для быстрой проверки
```
