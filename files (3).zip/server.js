import express from "express";
import { analyzeNiche } from "./analyze.js";

const app = express();
app.use(express.json());

// ─── POST /analyze ────────────────────────────────────────────────────────────
// Body: { "niche": "юридические услуги для ИП" }
// Returns: { ok, data, cached, ms }

app.post("/analyze", async (req, res) => {
  const { niche } = req.body;

  if (!niche || typeof niche !== "string" || niche.trim().length < 2) {
    return res.status(400).json({ ok: false, error: "niche is required" });
  }

  const t0 = Date.now();

  try {
    const result = await analyzeNiche(niche);
    return res.json({ ...result, ms: Date.now() - t0 });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ ok: false, error: err.message });
  }
});

// ─── GET /health ──────────────────────────────────────────────────────────────

app.get("/health", (_req, res) => res.json({ status: "ok" }));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Listening on http://localhost:${PORT}`));
