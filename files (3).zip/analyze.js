import Anthropic from "@anthropic-ai/sdk";

// ─── System prompt ───────────────────────────────────────────────────────────

const SYSTEM_PROMPT = (retrievedProfile) => `
Ты — маркетинговый аналитик. Твоя задача: по названию ниши
создать структурированный психографический профиль целевой аудитории.

Правила:
- Отвечай ТОЛЬКО валидным JSON, без пояснений
- Без markdown, без \`\`\`json\`\`\` обёрток
- Без вводных слов («Конечно!», «Вот результат»)
- Если ниша неизвестна — всё равно сделай лучшее предположение

Контекст из базы ниш:
${retrievedProfile ? JSON.stringify(retrievedProfile, null, 2) : "// пусто — игнорируй блок"}

Схема ответа (строго следуй ей):
{
  "niche": string,
  "client_portrait": string,        // 1-2 предложения
  "pains": string[],                // 4-6 пунктов
  "fears": string[],                // 4-6 пунктов
  "trust_triggers": string[],       // 3-5 пунктов
  "tone_of_voice": string,          // одна фраза
  "headline_formula": string,       // шаблон заголовка
  "cta": string,                    // призыв к действию
  "palette": [                      // ровно 4 цвета
    { "role": string, "hex": string, "reason": string }
  ],
  "block_order": string[]           // порядок блоков сайта
}
`.trim();

// ─── Статическая база ниш (замените pgvector в production) ───────────────────

const NICHE_DB = [
  {
    tags: ["юрист", "юридические", "адвокат", "право", "закон"],
    profile: {
      niche: "Юридические услуги",
      client_portrait:
        "Собственник ИП или ООО, столкнулся с острой проблемой: претензия, проверка, спор. Хочет решение — не лекцию.",
      pains: [
        "Получил претензию и не знаю как реагировать",
        "Контрагент не платит уже 3 месяца",
        "Налоговая требует документы — паника",
      ],
      fears: [
        "Юрист возьмёт деньги и исчезнет",
        "Потрачу больше на юриста, чем стоит само дело",
        "Не поймут специфику моего бизнеса",
      ],
      trust_triggers: [
        "Кейс с конкретными цифрами из похожего дела",
        "Первая консультация бесплатно",
        "Ответ в течение часа",
      ],
      tone_of_voice: "Чёткий, уверенный, без жаргона",
      cta: "Опишите ситуацию — ответим за 60 минут",
      palette: [
        { role: "primary", hex: "#1A2744", reason: "авторитет" },
        { role: "accent", hex: "#2B4C8C", reason: "доверие" },
        { role: "highlight", hex: "#C9A84C", reason: "статус" },
        { role: "background", hex: "#F5F6F8", reason: "чистота" },
      ],
      block_order: [
        "hero",
        "pain_points",
        "how_it_works",
        "cases",
        "trust",
        "faq",
        "cta_final",
      ],
    },
  },
  {
    tags: ["ремонт", "строительство", "отделка", "квартира"],
    profile: {
      niche: "Ремонт квартир",
      client_portrait:
        "Владелец квартиры или новостройки, делает ремонт первый или второй раз. Боится обмана и некачественной работы.",
      pains: [
        "Не знаю кому доверять",
        "Боюсь, что выйдет дороже и дольше чем обещали",
        "Уже обжигался с прошлой бригадой",
        "Не разбираюсь в материалах",
      ],
      fears: [
        "Пропадут с деньгами на полпути",
        "Красивые фото, а на деле халтура",
        "Смета вырастет в 2 раза",
        "Ремонт растянется на год",
      ],
      trust_triggers: [
        "Фото до/после с реальными адресами",
        "Фиксированная смета с гарантией",
        "Видео с объекта в процессе работы",
        "Договор до начала работ",
      ],
      tone_of_voice: "Тёплый, честный, «мы как для себя»",
      cta: "Приедем, замерим и дадим смету — бесплатно",
      palette: [
        { role: "primary", hex: "#2C3E2D", reason: "надёжность" },
        { role: "accent", hex: "#5C8A6E", reason: "материал" },
        { role: "highlight", hex: "#D4945A", reason: "теплота" },
        { role: "background", hex: "#F9F6F0", reason: "уют" },
      ],
      block_order: [
        "hero",
        "portfolio",
        "how_it_works",
        "pricing",
        "reviews",
        "trust",
        "cta_final",
      ],
    },
  },
  {
    tags: ["консалтинг", "консультации", "бизнес", "стратегия", "управление"],
    profile: {
      niche: "Бизнес-консультации",
      client_portrait:
        "Собственник малого бизнеса 35–55 лет, выручка 5–50 млн/год. Ощущает потолок роста, всё держится лично на нём.",
      pains: [
        "Нет системы — всё держится на мне",
        "Команда не работает без контроля",
        "Деньги есть, но куда вкладывать — непонятно",
        "Конкуренты растут быстрее",
      ],
      fears: [
        "Заплачу — не получу результат",
        "Консультант не знает мою отрасль",
        "Это красивые слайды без практики",
        "Придётся всё менять, а это страшно",
      ],
      trust_triggers: [
        "Кейс с цифрами из той же ниши",
        "ROI первого месяца работы",
        "Бесплатный аудит как первый шаг",
        "Отзыв похожего клиента",
      ],
      tone_of_voice: "Деловой, конкретный, без воды",
      cta: "Разберём вашу ситуацию за 30 минут — бесплатно",
      palette: [
        { role: "primary", hex: "#1B2B4B", reason: "авторитет" },
        { role: "accent", hex: "#2D5FA0", reason: "доверие" },
        { role: "highlight", hex: "#E8A94D", reason: "результат" },
        { role: "background", hex: "#F5F7FA", reason: "ясность" },
      ],
      block_order: [
        "hero",
        "pain_points",
        "cases",
        "how_it_works",
        "about",
        "reviews",
        "cta_final",
      ],
    },
  },
];

// ─── Поиск похожей ниши (простой текстовый матч, замените на pgvector) ────────

function findSimilarNiche(normalizedNiche) {
  const q = normalizedNiche.toLowerCase();
  let best = null;
  let bestScore = 0;

  for (const entry of NICHE_DB) {
    const score = entry.tags.filter((tag) => q.includes(tag)).length;
    if (score > bestScore) {
      bestScore = score;
      best = entry.profile;
    }
  }

  return bestScore > 0 ? best : null;
}

// ─── Нормализация ввода ───────────────────────────────────────────────────────

function normalizeNiche(raw) {
  return raw
    .trim()
    .toLowerCase()
    .replace(/\s+/g, " ")
    .replace(/ё/g, "е")
    .replace(/[^\wа-яa-z\s]/gi, "");
}

// ─── Основная функция ─────────────────────────────────────────────────────────

export async function analyzeNiche(rawNiche) {
  const client = new Anthropic();

  // 1. Нормализация
  const normalized = normalizeNiche(rawNiche);
  console.log(`[analyze] normalized: "${normalized}"`);

  // 2. Поиск похожей ниши в базе
  const retrieved = findSimilarNiche(normalized);
  console.log(`[analyze] retrieved: ${retrieved ? retrieved.niche : "none"}`);

  // 3. Запрос к Claude
  const response = await client.messages.create({
    model: "claude-sonnet-4-20250514",
    max_tokens: 1024,
    system: SYSTEM_PROMPT(retrieved),
    messages: [{ role: "user", content: `Ниша: "${normalized}"` }],
  });

  const raw = response.content[0].text.trim();

  // 4. Парсинг JSON
  try {
    const result = JSON.parse(raw);
    return { ok: true, data: result, cached: !!retrieved };
  } catch (e) {
    // Попытка вырезать JSON если модель всё же добавила что-то лишнее
    const match = raw.match(/\{[\s\S]*\}/);
    if (match) {
      return { ok: true, data: JSON.parse(match[0]), cached: !!retrieved };
    }
    return { ok: false, error: "JSON parse failed", raw };
  }
}
